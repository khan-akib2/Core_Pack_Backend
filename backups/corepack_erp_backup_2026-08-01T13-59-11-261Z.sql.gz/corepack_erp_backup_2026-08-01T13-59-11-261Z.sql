-- MySQL dump 10.13  Distrib 8.4.10-10, for Linux (x86_64)
--
-- Host: localhost    Database: corepack_erp
-- ------------------------------------------------------
-- Server version	8.4.10-10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `resourceId` varchar(255) DEFAULT NULL,
  `details` text,
  `ipAddress` varchar(255) DEFAULT NULL,
  `userAgent` text,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_settings`
--

DROP TABLE IF EXISTS `company_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyName` varchar(255) DEFAULT 'CORE PACK INDIA',
  `tagline` varchar(255) DEFAULT 'Manufacturers of Wooden & Corrugated Packaging Solutions',
  `logoUrl` varchar(255) DEFAULT '',
  `gstin` varchar(255) DEFAULT '27AAAAA0000A1Z5',
  `email` varchar(255) DEFAULT 'info@corepackindia.com',
  `phone` varchar(255) DEFAULT '+91 98765 43210',
  `alternatePhone` varchar(255) DEFAULT '',
  `address` text,
  `bankDetails` text,
  `categories` text,
  `certificationText` text,
  `challanBannerText` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_settings`
--

LOCK TABLES `company_settings` WRITE;
/*!40000 ALTER TABLE `company_settings` DISABLE KEYS */;
INSERT INTO `company_settings` VALUES (1,'Core PAck','core pack','','27qqqqqqq','ramzankhan4212@gmail.com','09920136318','','{\"street\":\"Royal Garden , A-2 Wing , opp.zanabiya complex , kausa-mumbra\",\"city\":\"Mumbra\",\"state\":\"Maharashtra\",\"pincode\":\"400612\",\"stateCode\":\"27\",\"country\":\"India\"}','{\"bankName\":\"Akib\",\"accountNumber\":\"Akib\",\"accountNo\":\"Akib\",\"ifscCode\":\"2345\",\"ifsc\":\"2345\",\"branch\":\"2345\"}','[\"Wooden Packaging Boxes\",\"Shabn\"]','Akib','akib','2026-07-27 18:35:26','2026-08-01 10:19:48');
/*!40000 ALTER TABLE `company_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `counters`
--

DROP TABLE IF EXISTS `counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `counters` (
  `name` varchar(255) NOT NULL,
  `seq` int DEFAULT '1000',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `counters`
--

LOCK TABLES `counters` WRITE;
/*!40000 ALTER TABLE `counters` DISABLE KEYS */;
INSERT INTO `counters` VALUES ('challan_2026-27',5,'2026-07-30 18:47:28','2026-08-01 10:48:01'),('quote_2026-27',3,'2026-07-31 12:30:15','2026-08-01 09:26:26');
/*!40000 ALTER TABLE `counters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `companyName` varchar(255) NOT NULL,
  `gstin` varchar(255) DEFAULT '',
  `phone` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT '',
  `billingAddress` text,
  `shippingAddress` text,
  `isActive` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Rajesh Kumar','Tata AutoComp Systems Ltd','27AAACT1234P1Z2','+91 98765 43210','procurement@tataautocomp.com','{\"street\":\"Gat No. 312, Chakan Industrial Area\",\"city\":\"Pune\",\"state\":\"Maharashtra\",\"stateCode\":\"27\",\"pincode\":\"410501\"}',NULL,1,'2026-07-27 18:35:48','2026-07-27 18:35:48',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_challans`
--

DROP TABLE IF EXISTS `delivery_challans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_challans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `challanNumber` varchar(255) NOT NULL,
  `challanDate` datetime DEFAULT NULL,
  `customerId` int DEFAULT NULL,
  `customerSnapshot` text,
  `transportDetails` text,
  `items` text,
  `status` varchar(255) DEFAULT 'Dispatched',
  `remarks` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `vehicleNo` varchar(255) DEFAULT '',
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `challanNumber` (`challanNumber`),
  UNIQUE KEY `challanNumber_2` (`challanNumber`),
  UNIQUE KEY `challanNumber_3` (`challanNumber`),
  UNIQUE KEY `challanNumber_4` (`challanNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_challans`
--

LOCK TABLES `delivery_challans` WRITE;
/*!40000 ALTER TABLE `delivery_challans` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_challans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceNumber` varchar(255) NOT NULL,
  `invoiceDate` datetime DEFAULT NULL,
  `dueDate` datetime DEFAULT NULL,
  `customerId` int DEFAULT NULL,
  `customerSnapshot` text,
  `challanNumber` varchar(255) DEFAULT '',
  `challanDate` datetime DEFAULT NULL,
  `transportDetails` text,
  `items` text,
  `subtotal` float DEFAULT '0',
  `discountTotal` float DEFAULT '0',
  `transportationCharges` float DEFAULT '0',
  `cgstTotal` float DEFAULT '0',
  `sgstTotal` float DEFAULT '0',
  `igstTotal` float DEFAULT '0',
  `isInterstate` tinyint(1) DEFAULT '0',
  `grandTotal` float DEFAULT '0',
  `amountInWords` varchar(255) DEFAULT '',
  `paidAmount` float DEFAULT '0',
  `dueAmount` float DEFAULT '0',
  `balanceAmount` float DEFAULT '0',
  `paymentStatus` varchar(255) DEFAULT 'Unpaid',
  `payments` text,
  `status` varchar(255) DEFAULT 'Issued',
  `terms` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `vehicleNo` varchar(255) DEFAULT '',
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoiceNumber` (`invoiceNumber`),
  UNIQUE KEY `invoiceNumber_2` (`invoiceNumber`),
  UNIQUE KEY `invoiceNumber_3` (`invoiceNumber`),
  UNIQUE KEY `invoiceNumber_4` (`invoiceNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (2,'001','2026-08-01 00:00:00','2026-08-16 11:05:40',1,'{\"name\":\"Rajesh Kumar\",\"companyName\":\"Tata AutoComp Systems Ltd\",\"gstin\":\"27AAACT1234P1Z2\",\"email\":\"procurement@tataautocomp.com\",\"phone\":\"+91 98765 43210\",\"billingAddress\":{\"street\":\"Gat No. 312, Chakan Industrial Area\",\"city\":\"Pune\",\"state\":\"Maharashtra\",\"stateCode\":\"27\",\"pincode\":\"410501\"},\"shippingAddress\":{}}','001','2026-09-04 00:00:00',NULL,'[{\"productId\":7,\"name\":\"akib\",\"hsnCode\":\"44151000\",\"qty\":1,\"rate\":0,\"discount\":0,\"unit\":\"Pcs\",\"taxRate\":5,\"taxableAmount\":0,\"boxSize\":\"\",\"palletSize\":\"\",\"cgst\":0,\"sgst\":0,\"igst\":0,\"totalAmount\":0}]',0,0,100,2.5,2.5,0,0,105,'One Hundred Five Rupees Only',0,105,105,'Unpaid','[]','Issued','[\"\"]','2026-08-01 11:05:40','2026-08-01 11:05:40',' vsvdvsd',NULL);
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sku` varchar(255) DEFAULT '',
  `category` varchar(255) NOT NULL DEFAULT 'Wooden Packaging Boxes',
  `hsnCode` varchar(255) NOT NULL DEFAULT '44151000',
  `gstRate` float DEFAULT '5',
  `defaultRate` float DEFAULT '0',
  `unit` varchar(255) DEFAULT 'Pcs',
  `description` text,
  `isActive` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (6,'E\\E 811V','','Wooden Packaging Boxes','44151000',5,0,'Pcs','',1,'2026-07-31 18:07:45','2026-07-31 18:07:45',NULL),(7,'akib','','Wooden Packaging Boxes','44151000',5,0,'Pcs','',1,'2026-08-01 10:16:34','2026-08-01 10:16:34',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quoteNumber` varchar(255) NOT NULL,
  `quoteDate` datetime DEFAULT NULL,
  `validUntil` datetime DEFAULT NULL,
  `customerId` int DEFAULT NULL,
  `customerSnapshot` text,
  `items` text,
  `subtotal` float DEFAULT '0',
  `cgstTotal` float DEFAULT '0',
  `sgstTotal` float DEFAULT '0',
  `igstTotal` float DEFAULT '0',
  `grandTotal` float DEFAULT '0',
  `status` varchar(255) DEFAULT 'Sent',
  `terms` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quoteNumber` (`quoteNumber`),
  UNIQUE KEY `quoteNumber_2` (`quoteNumber`),
  UNIQUE KEY `quoteNumber_3` (`quoteNumber`),
  UNIQUE KEY `quoteNumber_4` (`quoteNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `deviceType` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `ipAddress` varchar(255) DEFAULT NULL,
  `userAgent` text,
  `refreshTokenHash` varchar(255) NOT NULL,
  `isActive` tinyint(1) DEFAULT '1',
  `loginTime` datetime DEFAULT NULL,
  `lastActive` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `passwordHash` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT 'Admin',
  `customPermissions` text,
  `isActive` tinyint(1) DEFAULT '1',
  `phone` varchar(255) DEFAULT '',
  `refreshTokenHash` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `failedLoginAttempts` int DEFAULT '0',
  `lockUntil` datetime DEFAULT NULL,
  `passwordChangedAt` datetime DEFAULT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`),
  UNIQUE KEY `email_3` (`email`),
  UNIQUE KEY `email_4` (`email`),
  UNIQUE KEY `email_5` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'CorePack Admin','admin@corepack.in','$2a$10$TjZayNPw5kbNTCp96glizuju.yMr4T.UZIgx/1iWbyKRmq/DUzM1e','Admin','[]',1,'+91 98200 12345','$2a$10$cX76QxGfJr6dwbcR9r33Ie97J.BgDPHdlnpNBUIU0ELPz2XMIaHn.','2026-07-27 18:35:48','2026-08-01 09:57:51',NULL,0,NULL,NULL,NULL),(2,'CorePack Admin','admin.corepack@gmail.com','$2a$10$.ZKh4RFHTBQUjIzQy9CMHuRV55ltUJdB422ELDe/Jy2Qk0bgkXC0W','Admin','[]',1,'+91 98200 12345','$2a$10$5ddxg5VzJlQFtOqtmihHEOJO5TVR4e34s5lx74RYPZGgEjFQ75JE2','2026-08-01 12:25:21','2026-08-01 12:28:44',NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-01 19:29:11
